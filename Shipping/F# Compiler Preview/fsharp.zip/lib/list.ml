(* (c) Microsoft Corporation. All rights reserved *)
let hd l = match l with (x:: _) -> x | [] -> invalid_arg "hd"
let tl l = match l with (_ :: t) -> t | [] -> invalid_arg "tl"

let nonempty x = match x with [] -> false | _ -> true

let length l = 
  let mutable res = 0 in 
  let mutable curr = l in 
  while (nonempty curr) do 
    res <- succ res;
    curr <- curr.(::).1
  done;
  res

let rec nth l n = 
  if l = [] or n < 0 then invalid_arg "nth" 
  else if n = 0 then hd l else nth (tl l) (n - 1)

let rev l = 
   let mutable res = [] in 
   let mutable curr = l in 
   while nonempty curr do
     res <- curr.(::).0 :: res; 
     curr <- curr.(::).1;
   done;
   res


let append l1 l2 = l1 @ l2
let rev_append l1 l2 = 
  let mutable res = l2 in 
  let mutable curr = l1 in 
  while nonempty curr do
    res <- curr.(::).0 :: res;
    curr <- curr.(::).1;
  done;
  res

let rec fold_right f l acc = 
  match l with 
    [] -> acc
  | (h::t) -> f h (fold_right f t acc)

let rec fold_left f acc l = 
  match l with 
    [] -> acc
  | (h::t) -> fold_left f (f acc h) t

let rec concat l = 
  match l with 
    [] -> []
  | [h] -> h
  | h::t -> h @ concat t
let flatten l = concat l

let rec iter f x = match x with [] -> () | (h::t) -> f h; iter f t

let map f x = 
  match x with
  | [] -> []
  | (h::t) -> 
      let res = [f h] in 
      let mutable curr = t in 
      let mutable cell = res in 
      while nonempty curr do
	let nw = [f curr.(::).0] in
	cell.(::).1 <- nw;
	curr <- curr.(::).1;
	cell <- nw
      done;
      res

(* let rec map f x = match x with [] -> [] | (h::t) -> let x = f h in x :: map f t *)

let rev_map f l =
   let mutable res = [] in 
   let mutable curr = l in 
   while nonempty curr do
     let h::t = curr in
     res <- f h :: res;
     curr <- t;
   done;
   res

let rec iter2 f l1 l2 = 
  match l1,l2 with
    [],[] -> () 
  | (h1::t1), (h2::t2) -> f h1 h2; iter2 f t1 t2 
  | _ -> invalid_arg "iter2"
let rec map2 f l1 l2 = 
  match l1,l2 with
    [],[] -> [] 
  | (h1::t1), (h2::t2) -> let x = f h1 h2 in x :: map2 f t1 t2
  | _ -> invalid_arg "map2"
let rev_map2 f l1 l2 =
   let mutable res = [] in 
   let mutable curr1 = l1 in 
   let mutable curr2 = l2 in 
   while (match curr1, curr2 with [],[] -> false | [],_ | _,[] -> invalid_arg "rev_map2" | _ -> true) do
     let h1::t1 = curr1 in
     let h2::t2 = curr2 in
     res <- f h1 h2 :: res;
     curr1 <- t1;
     curr2 <- t2;
   done;
   res

let rec fold_left2 f acc l1 l2 = 
  match l1,l2 with 
    [],[] -> acc
  | (h1::t1),(h2::t2) -> fold_left2 f (f acc h1 h2) t1 t2
  | _ -> invalid_arg "fold_left2"

let rec fold_right2 f l1 l2 acc = 
  match l1,l2 with 
    [],[] -> acc
  | (h1::t1),(h2::t2) -> f h1 h2 (fold_right2 f t1 t2 acc)
  | _ -> invalid_arg "fold_right2"

let rec for_all2 f l1 l2 = 
  match l1,l2 with 
    [],[] -> true
  | (h1::t1),(h2::t2) -> f h1 h2  & for_all2 f t1 t2
  | _ -> invalid_arg "for_all2"

let rec for_all f l1 = 
  match l1 with 
    [] -> true
  | (h1::t1) -> f h1  & for_all f t1

let rec exists f l1 = 
  match l1 with 
    [] -> false
  | (h1::t1) -> f h1  or exists f t1

let rec exists2 f l1 l2 = 
  match l1,l2 with 
    [],[] -> false
  | (h1::t1),(h2::t2) -> f h1 h2  or exists2 f t1 t2
  | _ -> invalid_arg "exists2"

let rec mem x l = match l with [] -> false | h::t -> x = h or mem x t
let rec memq x l = match l with [] -> false | h::t -> x == h or memq x t
let rec find f l = match l with [] -> raise Not_found | h::t -> if f h then h else find f t

(* non-tailrecursive: allocate in preference to using stack *)
let rec filter f x = 
  match x with 
  | [] -> []
  | [h] -> if f h then x else []
  | h1 :: ((h2 :: []) as y) -> if f h1 then h1::filter f y else filter f y
  | _ ->
      let mutable res1 = [] in 
      let mutable curr = x in 
      while nonempty curr do
	let h = curr.(::).0 in
	if f h then 
	  res1 <- h :: res1;
	curr <- curr.(::).1;
      done;
      rev res1

let find_all f x = filter f x

(* non-tailrecursive: allocate in preference to using stack *)
let rec partition f x = 
  match x with 
    [] -> [],[]
  | [h] -> if f h then x,[] else [],x
  | _ ->
      let mutable res1 = [] in 
      let mutable res2 = [] in 
      let mutable curr = x in 
      while nonempty curr do
	let h = curr.(::).0 in
	if f h then 
	  res1 <- h :: res1
	else 
	  res2 <- h :: res2;
	curr <- curr.(::).1;
      done;
      rev res1, rev res2
    
let rec assoc x l = 
  match l with 
    [] -> raise Not_found
  | ((h,r)::t) -> if x = h then r else assoc x t

let rec assq x l = 
  match l with 
    [] -> raise Not_found
  | ((h,r)::t) -> if x == h then r else assq x t

let rec mem_assoc x l = 
  match l with 
    [] -> false
  | ((h,r)::t) -> x = h or mem_assoc x t

let rec mem_assq x l = 
  match l with 
    [] -> false
  | ((h,r)::t) -> x == h or mem_assq x t

let rec remove_assoc x l = 
  match l with 
    [] -> []
  | (((h,r) as p) ::t) -> if x = h then t else p:: remove_assoc x t

let rec remove_assq x l = 
  match l with 
    [] -> []
  | (((h,r) as p) ::t) -> if x == h then t else p:: remove_assq x t

let rec split x = 
  match x with 
    [] -> [],[]
  | ((h1,h2)::t) -> let l1,l2 = split t in (h1::l1, h2::l2)

let rec combine x1 x2 = 
  match x1,x2 with 
    [],[] -> []
  | (h1::t1),(h2::t2) -> (h1,h2):: combine t1 t2
  | _ -> invalid_arg "combine"


let half x = x lsr 1 

let rec merge cmp a b = 
  match a,b with 
  | [], b -> b
  | a, [] -> a
  | x::a', y::b' -> if cmp x y = 1 
  then y::merge cmp a  b' 
  else x::merge cmp a' b  

let sort2 cmp x y = 
  if cmp x y = 1 then [y;x] else [x;y]

let sort3 cmp x y z = 
  let cxy = cmp x y in 
  let cyz = cmp y z in 
  if cxy = 1 && cyz = -1 then 
    if cmp x z = 1 then [y;z;x] else [y;x;z]
  else if cxy = -1 & cyz = 1 then 
    if cmp x z = 1 then [z;x;y] else [x;z;y]
  else if cxy = 1 or cyz = 1 then  [z;y;x]
  else [x;y;z] 

let trivial a = match a with [] | [_] -> true | _ -> false
    
(* tail recursive using a ref *)

let stable_sort cmp a =
  if trivial a then a else
  let ar = ref a in
  let rec sort la =
    if la < 4 then (* sort two or three new entries *)
      match !ar with x::y::b -> 
	if la = 2 then ( ar := b; sort2 cmp x y )
	else ( match b with z::c -> ( ar := c; sort3 cmp x y z )
	| _ -> failwith "never" ) 
      | _ -> failwith "never"
    else (* divide *)
      let lb = half la in
      let sb = sort lb in
      let sc = sort (la - lb) in 
      merge cmp sb sc 
  in 
  sort (length a)

let sort f l = stable_sort f l
