(* (c) Microsoft Corporation. All rights reserved *)
type spec =
  | Unit of (unit -> unit)
  | Set of bool ref
  | Clear of bool ref
  | String of (string -> unit)
  | Int of (int -> unit)
  | Float of (float -> unit)
  | Rest of (string -> unit)

exception Bad of string

let usage specs u =  
  prerr_endline ("usage: "^u);
  List.iter (function 
    | (s, (Unit _ | Set _ | Clear _), x) -> prerr_string "\t"; prerr_string s; prerr_string ": "; prerr_endline x
    | (s, String f, x) -> prerr_string "\t"; prerr_string s; prerr_string " <string>: "; prerr_endline x
    | (s, Int f, x) -> prerr_string "\t"; prerr_string s; prerr_string " <int>: "; prerr_endline x
    | (s, Float f, x) ->  prerr_string "\t"; prerr_string s; prerr_string " <float>: "; prerr_endline x
    | (s, Rest f, x) -> prerr_string "\t"; prerr_string s; prerr_string " ...: "; prerr_endline x)
    specs;
  prerr_string "\t"; prerr_string "--help"; prerr_string ": "; prerr_endline "display this list of options";
  prerr_string "\t"; prerr_string "-help"; prerr_string ": "; prerr_endline "display this list of options"

type argspec = (string * spec * string) 
let parse specs other u =
  let error () = usage specs u; exit 1 in 
  let rec process args = 
    match args with 
    |	[] -> ()
    |	arg :: t -> 
	match arg with 
	| "-help" -> 
	    usage specs u; process t
	| "--help" -> usage specs u; process t
	| _ -> 
	    let rec attempt (specs: argspec  list) = 
	      match specs, t with 
	      | ((s, Unit f, _) :: _) , _ 
		  when s = arg -> 
		    f (); 
		    t
	      | ((s, Set f, _) :: _) , _ when s = arg -> f := true; t
	      | ((s, Clear f, _) :: _) , _ when s = arg -> f := false; t
	      | ((s, String f, _) :: _) , h2::t2 when s = arg -> f h2; t2
	      | ((s, Int f, _) :: _) , h2::t2 when s = arg -> f (try int_of_string h2 with _ -> error()); t2
	      | ((s, Float f, _) :: _) , h2::t2 when s = arg -> f (try float_of_string h2 with _ -> error()); t2
	      | ((s, Rest f, _) :: _) , _ when s = arg -> List.iter f t; []
	      | (_ :: more) , _ -> attempt more 
	      | [], _ -> if String.get arg 0 = '-' then (prerr_endline ("unrecognized argument: "^ arg); error()) else (other arg; t) in 
	    let rest = attempt specs (* args *) in
	    process rest in
  process (List.tl (Array.to_list Sys.argv))

(* val current : int ref *)

