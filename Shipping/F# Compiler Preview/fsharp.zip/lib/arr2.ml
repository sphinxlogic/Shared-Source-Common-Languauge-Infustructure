(* (c) Microsoft Corporation. All rights reserved *)

(* Define the primitive operations. *)
(* Note: the "type" syntax is for the type parameter for inline *)
(* polymorphic IL. This helps the compiler inline these fragments, *)
(* i.e. work out the correspondence between IL and F# type variables. *)
let inline length1 (arr: ''a[,]) =  (# "ldlen.multi 2 0" arr : int)  
let inline length2 (arr: ''a[,]) =  (# "ldlen.multi 2 1" arr : int)  
let inline get (arr: ''a[,]) (n:int) (m:int) =  (# "ldelem.multi 2 !0" type (''a) arr n m : ''a)  
let inline set (arr: ''a[,]) (n:int) (m:int) (x:''a) =  (# "stelem.multi 2 !0" type (''a) arr n m x)  
let inline zero_create (n:int) (m:int) = (# "newarr.multi 2 !0" type (''a) n m : ''a[,])
let inline make  (n:int) (m:int) (x:''a) =
  let arr = (zero_create n m : ''a[,]) in 
  for i = 0 to n - 1 do 
    for j = 0 to m - 1 do 
      (set arr i j x)
    done;
  done;
  arr

let inline create (n:int) (m:int) (x:''a) = make n m x
let inline init (n:int) (m:int) (f: int -> int -> ''a) = 
  let arr = (zero_create n m : ''a[,])  in 
  for i = 0 to n - 1 do 
    for j = 0 to m - 1 do 
      set arr i j (f i j)
    done;
  done;
  arr

(*
let inline nonnull x = match x with [,] -> false | _ -> true

let inline concat (arrs:''a[,] list) =
  let lenall = List.fold_right (fun x y -> length x + y) arrs 0 in 
  let res = (zero_create lenall : ''a[,]) in 
  let mutable base = 0 in
  let mutable curr = arrs in 
  while nonnull curr do
    let arr::t = curr in
    let len = length arr in 
    for i = 0 to len - 1 do 
      (set res (base + i) (get arr i : ''a))
    done;
    base <- base + len;
    curr <- t;
  done;
  res

let inline append arr1 arr2 = concat [arr1; arr2]

let inline sub (arr:''a[,]) (start:int) (len:int) =
  let res = (zero_create len : ''a[,])  in
  for i = 0 to len - 1 do 
    (set res i (get arr (start + i) : ''a))
  done;
  res

let inline fill (arr:''a[,]) (start:int) (len:int) (x:''a) =
  for i = start to start + len - 1 do 
    (set arr i x)
  done

let inline copy arr = concat [arr]

let inline blit (arr1:''a[,]) (start1:int) (arr2: ''a[,]) (start2:int) (len:int) =
  for i = 0 to len - 1 do 
    (set arr2 (start2+i) (get arr1 (start1 + i) : ''a))
  done

*)
let inline iter (f : ''a -> unit) (arr:''a[,]) =
  let len1 = length1 arr in 
  let len2 = length2 arr in 
  for i = 0 to len1 - 1 do 
    for j = 0 to len2 - 1 do 
      f (get arr i j)
    done;
  done

let inline map (f: ''a -> ''b) (arr:''a[,]) =
  let len1 = length1 arr in 
  let len2 = length2 arr in 
  let res = (zero_create len1 len2 : ''b[,]) in 
  for i = 0 to len1 - 1 do 
    for j = 0 to len2 - 1 do 
      set res i j (f (get arr i j))
    done;
  done;
  res

let inline iteri (f : int -> int -> ''a -> unit) (arr:''a[,]) =
  let len1 = length1 arr in 
  let len2 = length2 arr in 
  for i = 0 to len1 - 1 do 
    for j = 0 to len2 - 1 do 
      f i j (get arr i j)
    done;
  done

let inline mapi (f: int -> int -> ''a -> ''b) (arr:''a[,]) =
  let len1 = length1 arr in 
  let len2 = length2 arr in 
  let res = (zero_create len1 len2 : ''b[,]) in 
  for i = 0 to len1 - 1 do 
    for j = 0 to len2 - 1 do 
      set res i j (f i j (get arr i j))
    done;
  done;
  res

(*
let inline fold_left (f : ''a -> ''b -> ''a) (acc: ''a) (arr:''b[,]) =
  let mutable res = acc in 
  let len = length arr in 
  for i = 0 to len - 1 do 
    res <- f res (get arr i)
  done;
  res

let inline fold_right (f : ''a -> ''b -> ''b) (arr:''a[,]) (acc: ''b) =
  let mutable res = acc in 
  let len = length arr in 
  for i = len - 1 downto 0 do 
    res <- f (get arr i) res
  done;
  res


*)

