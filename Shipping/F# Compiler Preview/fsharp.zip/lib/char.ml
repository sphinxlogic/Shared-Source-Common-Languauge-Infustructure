let code (c:char) = (# "" c : int)
let chr (n:int) =  (# "conv.u2" n : char)
let lowercase (c:char) = System.Char.ToLower(c)
let uppercase (c:char) = System.Char.ToUpper(c)
