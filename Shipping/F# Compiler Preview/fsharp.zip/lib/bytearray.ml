(* (c) Microsoft Corporation. All rights reserved *)
type bytearray = byte[]
let length (arr: byte[]) =  (# "ldlen" arr : int)  
let get (arr: byte[]) (n:int) =  (# "ldelem.i1" arr n : byte)  
let set (arr: byte[]) (n:int) (x:byte) =  (# "stelem.i1" arr n x)  
let zero_create (n:int) = (# "newarr unsigned int8" n : byte[])
let make  (n:int) = (zero_create n : byte[]) 

let create (n:int)  = make n
let init (n:int) (f: int -> byte) = 
  let arr = (zero_create n : byte[])  in 
  for i = 0 to n - 1 do 
    set arr i (f i)
  done;
  arr

let concat (arrs:byte[] list) =
  let lenall = List.fold_right (fun x y -> length x + y) arrs 0 in 
  let res = (zero_create lenall : byte[]) in 
  let base = ref 0 in
  List.iter
    (fun arr -> 
      let len = length arr in 
      for i = 0 to len - 1 do 
	(set res (!base + i) (get arr i : byte))
      done;
      base := !base + len)
    arrs;
  res

let append arr1 arr2 = concat [arr1; arr2]

let sub (arr:byte[]) (start:int) (len:int) =
  let res = (zero_create len : byte[])  in
  for i = 0 to len - 1 do 
    (set res i (get arr (start + i) : byte))
  done;
  res

let fill (arr:byte[]) (start:int) (len:int) (x:byte) =
  for i = start to start + len - 1 do 
    (set arr i x)
  done

let copy arr = concat [arr]

let blit (arr1:byte[]) (start1:int) (arr2: byte[]) (start2:int) (len:int) =
  for i = 0 to len - 1 do 
    (set arr2 (start2+i) (get arr1 (start1 + i) : byte))
  done

let to_list (arr:byte[]) =
  let len = length arr in 
  let res = ref ([]: byte list) in 
  for i = len - 1 downto 0 do 
    res := (get arr i) :: !res
  done;
  !res
  
let of_list (l:byte list) =
  let len = List.length l in 
  let res = (zero_create len : byte[]) in 
  let lref = ref l in 
  for i = 0 to len - 1 do 
    let h :: t = !lref in 
    set res i h;
    lref := t
  done;
  res

let iter (f : byte -> unit) (arr:byte[]) =
  let len = length arr in 
  for i = 0 to len - 1 do 
    f (get arr i)
  done

let map (f: byte -> byte) (arr:byte[]) =
  let len = length arr in 
  let res = (zero_create len : byte[]) in 
  for i = 0 to len - 1 do 
    set res i (f (get arr i))
  done;
  res

let iteri (f : int -> byte -> unit) (arr:byte[]) =
  let len = length arr in 
  for i = 0 to len - 1 do 
    f i (get arr i)
  done


let mapi (f: int -> byte -> byte) (arr:byte[]) =
  let len = length arr in 
  let res = (zero_create len : byte[]) in 
  for i = 0 to len - 1 do 
    set res i  (f i (get arr i))
  done;
  res

let fold_left (f : byte -> byte -> byte) (acc: byte) (arr:byte[]) =
  let res = ref acc in 
  let len = length arr in 
  for i = 0 to len - 1 do 
    res := f !res (get arr i)
  done;
  !res

let fold_right (f : byte -> byte -> byte) (arr:byte[]) (acc: byte) =
  let res = ref acc in 
  let len = length arr in 
  for i = len - 1 downto 0 do 
    res := f (get arr i) !res
  done;
  !res

type encoding = System.Text.Encoding

let ascii_to_string (b:byte[]) = System.Text.Encoding.ASCII.GetString(b)
  
let string_to_ascii (s:string) = System.Text.Encoding.ASCII.GetBytes(s)
