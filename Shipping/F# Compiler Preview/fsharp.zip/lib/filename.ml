(* (c) Microsoft Corporation. All rights reserved *)
let current_dir_name = "."
let parent_dir_name =  ".."
let concat (x:string) (y:string) = System.IO.Path.Combine (x,y)
let is_relative (s:string) = System.IO.Path.IsPathRooted(s)
let dirname (s:string) = System.IO.Path.GetDirectoryName(s)

let is_implicit (s:string) = 
  is_relative s &
  let d = dirname s in 
  d <> current_dir_name & d <> parent_dir_name

let check_suffix (x:string) (y:string) = x.EndsWith(y)

let chop_suffix (x:string) (y:string) =
  if not (check_suffix x y) then invalid_arg "chop_suffix";
  String.sub x 0 (String.length x - String.length y)

let has_extension (s:string) = System.IO.Path.HasExtension(s)

let chop_extension (s:string) =
  if not (has_extension s) then invalid_arg "chop_extension";
  concat (dirname s) (System.IO.Path.GetFileNameWithoutExtension(s))

let basename (s:string) = System.IO.Path.GetFileName(s)

(* TODO *) let temp_file (p:string) (s:string) = System.IO.Path.GetTempFileName()

let quote s = "\'" ^ s ^ "\'"  (* TODO - fix this *)

