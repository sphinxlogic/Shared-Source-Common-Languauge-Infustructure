(* (c) Microsoft Corporation. All rights reserved *)

(* Define the primitive operations. *)
(* Note: the "type" syntax is for the type parameter for inline *)
(* polymorphic IL. This helps the compiler inline these fragments, *)
(* i.e. work out the correspondence between IL and F# type variables. *)
let inline length (arr: ''a[]) =  (# "ldlen" arr : int)  
let inline get (arr: ''a[]) (n:int) =  (# "ldelem.any !0" type (''a) arr n : ''a)  
let inline set (arr: ''a[]) (n:int) (x:''a) =  (# "stelem.any !0" type (''a) arr n x)  
let inline zero_create (n:int) = (# "newarr !0" type (''a) n : ''a[])
let inline make  (n:int) (x:''a) =
  let arr = (zero_create n : ''a[]) in 
  for i = 0 to n - 1 do 
    (set arr i x)
  done;
  arr

let inline create (n:int) (x:''a) = make n x
let inline init (n:int) (f: int -> ''a) = 
  let arr = (zero_create n : ''a[])  in 
  for i = 0 to n - 1 do 
    set arr i (f i)
  done;
  arr

let inline make_matrix (n:int) (m:int) (x:''a) = 
  let arr = (zero_create n : ''a[][]) in 
  for i = 0 to n - 1 do 
    let inner = (zero_create m : ''a[]) in 
    for j = 0 to m - 1 do 
      (set inner j x)
    done;
    set arr i inner
  done;
  arr

let inline create_matrix n m x = make_matrix n m x
let inline nonnull x = match x with [] -> false | _ -> true

let inline concat (arrs:''a[] list) =
  let lenall = List.fold_right (fun x y -> length x + y) arrs 0 in 
  let res = (zero_create lenall : ''a[]) in 
  let mutable base = 0 in
  let mutable curr = arrs in 
  while nonnull curr do
    let arr::t = curr in
    let len = length arr in 
    for i = 0 to len - 1 do 
      (set res (base + i) (get arr i : ''a))
    done;
    base <- base + len;
    curr <- t;
  done;
  res

let inline append arr1 arr2 = concat [arr1; arr2]

let inline sub (arr:''a[]) (start:int) (len:int) =
  let res = (zero_create len : ''a[])  in
  for i = 0 to len - 1 do 
    (set res i (get arr (start + i) : ''a))
  done;
  res

let inline fill (arr:''a[]) (start:int) (len:int) (x:''a) =
  for i = start to start + len - 1 do 
    (set arr i x)
  done

let inline copy arr = concat [arr]

let inline blit (arr1:''a[]) (start1:int) (arr2: ''a[]) (start2:int) (len:int) =
  for i = 0 to len - 1 do 
    (set arr2 (start2+i) (get arr1 (start1 + i) : ''a))
  done

let inline to_list (arr:''a[]) =
  let len = length arr in 
  let mutable res = ([]: ''a list) in 
  for i = len - 1 downto 0 do 
    res <- (get arr i) :: res
  done;
  res
  
let inline of_list (l:''a list) =
  let len = List.length l in 
  let res = (zero_create len : ''a[]) in 
  let mutable lref = l in 
  for i = 0 to len - 1 do 
    let h :: t = lref in 
    set res i h;
    lref <- t
  done;
  res

let inline iter (f : ''a -> unit) (arr:''a[]) =
  let len = length arr in 
  for i = 0 to len - 1 do 
    f (get arr i)
  done

let inline map (f: ''a -> ''b) (arr:''a[]) =
  let len = length arr in 
  let res = (zero_create len : ''b[]) in 
  for i = 0 to len - 1 do 
    set res i (f (get arr i))
  done;
  res

let inline iteri (f : int -> ''a -> unit) (arr:''a[]) =
  let len = length arr in 
  for i = 0 to len - 1 do 
    f i (get arr i)
  done


let inline mapi (f: int -> ''a -> ''b) (arr:''a[]) =
  let len = length arr in 
  let res = (zero_create len : ''b[]) in 
  for i = 0 to len - 1 do 
    set res i  (f i (get arr i))
  done;
  res

let inline fold_left (f : ''a -> ''b -> ''a) (acc: ''a) (arr:''b[]) =
  let mutable res = acc in 
  let len = length arr in 
  for i = 0 to len - 1 do 
    res <- f res (get arr i)
  done;
  res

let inline fold_right (f : ''a -> ''b -> ''b) (arr:''a[]) (acc: ''b) =
  let mutable res = acc in 
  let len = length arr in 
  for i = len - 1 downto 0 do 
    res <- f (get arr i) res
  done;
  res


