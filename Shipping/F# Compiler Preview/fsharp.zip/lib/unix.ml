(* (c) Microsoft Corporation. All rights reserved *)
let date_to_float (d:System.DateTime) =   d.ToOADate()

type stats = 
    { st_atime : float;
      st_mtime : float;
      st_ctime : float; }

let stat (s:string) = 
  { st_atime = date_to_float (System.IO.File.GetLastAccessTime(s));
    st_mtime = date_to_float (System.IO.File.GetLastWriteTime(s));
    st_ctime = date_to_float (System.IO.File.GetCreationTime(s)); }
    
