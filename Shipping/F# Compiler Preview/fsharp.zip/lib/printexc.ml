
let to_string (e:exn) = 
  any_to_string e^"\n" (*  (box e).StackTrace *)

let print f x = try f x with e -> prerr_endline (to_string e) ; raise e 
let catch f x = try f x with e -> prerr_endline (to_string e); exit 2
