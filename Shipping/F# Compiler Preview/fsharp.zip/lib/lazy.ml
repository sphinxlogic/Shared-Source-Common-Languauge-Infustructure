(* (c) Microsoft Corporation. All rights reserved *)
type 'a status =
  | Delayed of (unit -> 'a)
  | Value of 'a
  | Exception of exn
type 'a t = 'a status ref
exception Undefined

let err = Exception Undefined

let force (x: 'a t) =
  match !x with 
  | Delayed f -> let res = f () in x := Value res; res
  | Value x -> x
  | Exception e -> raise e

let force_val x = force x

let lazy_from_fun f = ref (Delayed f)
let lazy_from_val v = ref (Value v)
let lazy_is_val x = match !x with Value _ -> true | _ -> false


