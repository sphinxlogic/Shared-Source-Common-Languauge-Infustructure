(* (c) Microsoft Corporation. All rights reserved *)

(* Define the primitive operations. *)
(* Note: the "type" syntax is for the type parameter for inline *)
(* polymorphic IL. This helps the compiler inline these fragments, *)
(* i.e. work out the correspondence between IL and F# type variables. *)
let length (arr: 'a array) =  (# "ldlen" arr : int)  
let get (arr: 'a array) (n:int) =  (# "ldelem.erasable !0" type ('a) arr n : 'a)  
let set (arr: 'a array) (n:int) (x:'a) =  (# "stelem.erasable !0" type ('a) arr n x)  
let zero_create (n:int) = (# "newarr.erasable !0" type ('a) n : 'a array)
let make  (n:int) (x:'a) =
  let arr = (zero_create n : 'a array) in 
  for i = 0 to n - 1 do 
    (set arr i x)
  done;
  arr

let create (n:int) (x:'a) = make n x
let init (n:int) (f: int -> 'a) = 
  let arr = (zero_create n : 'a array)  in 
  for i = 0 to n - 1 do 
    set arr i (f i)
  done;
  arr

let make_matrix (n:int) (m:int) (x:'a) = 
  let arr = (zero_create n : 'a array array) in 
  for i = 0 to n - 1 do 
    let inner = (zero_create m : 'a array) in 
    for j = 0 to m - 1 do 
      (set inner j x)
    done;
    set arr i inner
  done;
  arr

let create_matrix n m x = make_matrix n m x
let nonnull x = match x with [] -> false | _ -> true

let add_lengths (arrs:'a array list) =
  let mutable base = 0 in
  let mutable curr = arrs in 
  while nonnull curr do
    let arr::t = curr in
    let len = length arr in 
    base <- base + len;
    curr <- t;
  done;
  base

let concat (arrs:'a array list) =
  let lenall = add_lengths arrs in
  let res = (zero_create lenall : 'a array) in 
  let mutable base = 0 in
  let mutable curr = arrs in 
  while nonnull curr do
    let arr::t = curr in
    let len = length arr in 
    for i = 0 to len - 1 do 
      (set res (base + i) (get arr i : 'a))
    done;
    base <- base + len;
    curr <- t;
  done;
  res

let append arr1 arr2 = concat [arr1; arr2]

let sub (arr:'a array) (start:int) (len:int) =
  let res = (zero_create len : 'a array)  in
  for i = 0 to len - 1 do 
    (set res i (get arr (start + i) : 'a))
  done;
  res

let fill (arr:'a array) (start:int) (len:int) (x:'a) =
  for i = start to start + len - 1 do 
    (set arr i x)
  done

let copy arr = concat [arr]

let blit (arr1:'a array) (start1:int) (arr2: 'a array) (start2:int) (len:int) =
  for i = 0 to len - 1 do 
    (set arr2 (start2+i) (get arr1 (start1 + i) : 'a))
  done

let to_list (arr:'a array) =
  let len = length arr in 
  let mutable res = ([]: 'a list) in 
  for i = len - 1 downto 0 do 
    res <- (get arr i) :: res
  done;
  res
  
let of_list (l:'a list) =
  let len = List.length l in 
  let res = (zero_create len : 'a array) in 
  let mutable lref = l in 
  for i = 0 to len - 1 do 
    let h :: t = lref in 
    set res i h;
    lref <- t
  done;
  res

let iter (f : 'a -> unit) (arr:'a array) =
  let len = length arr in 
  for i = 0 to len - 1 do 
    f (get arr i)
  done

let map (f: 'a -> 'b) (arr:'a array) =
  let len = length arr in 
  let res = (zero_create len : 'b array) in 
  for i = 0 to len - 1 do 
    set res i (f (get arr i))
  done;
  res

let iteri (f : int -> 'a -> unit) (arr:'a array) =
  let len = length arr in 
  for i = 0 to len - 1 do 
    f i (get arr i)
  done

let mapi (f: int -> 'a -> 'b) (arr:'a array) =
  let len = length arr in 
  let res = (zero_create len : 'b array) in 
  for i = 0 to len - 1 do 
    set res i  (f i (get arr i))
  done;
  res

let fold_left (f : 'a -> 'b -> 'a) (acc: 'a) (arr:'b array) =
  let mutable res = acc in 
  let len = length arr in 
  for i = 0 to len - 1 do 
    res <- f res (get arr i)
  done;
  res

let fold_right (f : 'a -> 'b -> 'b) (arr:'a array) (acc: 'b) =
  let mutable res = acc in 
  let len = length arr in 
  for i = len - 1 downto 0 do 
    res <- f (get arr i) res
  done;
  res

(* @todo: this is gross. *)
let sort (f: 'a -> 'a -> int) arr = 
  let arr2 = of_list (List.sort f (to_list arr))  in
  for i = 0 to length arr - 1 do
    arr.(i) <- arr2.(i)
  done



