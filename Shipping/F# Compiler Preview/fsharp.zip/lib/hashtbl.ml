
let hash (x: 'a) = inbuilt_poly_hash x 2

type ('a, 'b) t = 
    { (*
      hash: 'a -> int;
      eq: 'a -> 'a -> bool; *) 
      mutable contents: ('a,'b) buckets array;
      mutable count: int }
and ('a,'b) buckets = Empty | Chain of 'a * 'b * ('a,'b) buckets

let norm (x: int) = (# "ldc.i4 0x7FFFFFFF and" x : int)

(*
let gen_create (hsh,eq) n =
  let size = max 1 n in 
  {hash=hsh; eq=eq; contents = Array.create size Empty; count = 0; }
*)
let create n = 
  let size = max 1 n in 
  { contents = Array.create size Empty; count = 0; }

let clear t = 
  let arr = t.contents in 
  for i = 0 to Array.length arr - 1 do arr.(i) <- Empty done;
  t.count <- 0

let notempty = function Empty -> false | Chain _ -> true
let iter f t = 
  let arr = t.contents in 
  let len = Array.length arr in 
  for i = 0 to len - 1 do 
    let mutable curr = arr.(i) in 
    while notempty curr do
      f curr.(Chain).0 curr.(Chain).1;
      curr <- curr.(Chain).2;
    done;
  done

let add t x y = 
  let arr = t.contents in 
  let osize = Array.length arr in 
  (* Resize table if it looks too full. *)
  if t.count > osize then begin 
    let nsize = (t.count * 4 + 1) in 
    let arr2 = Array.create nsize Empty in 
    for i = 0 to osize - 1 do 
      let mutable curr = arr.(i) in 
      while notempty curr do
	let x2 = curr.(Chain).0 in 
	let hc2 = (norm (hash x2)) mod nsize in 
	arr2.(hc2) <- Chain (x2,curr.(Chain).1,arr2.(hc2));
	curr <- curr.(Chain).2;
      done;      
    done;
    t.contents <- arr2;
  end;
  let arr2 = t.contents in 
  let hc = norm (hash x) mod (Array.length t.contents) in 
  arr2.(hc) <- Chain(x,y,arr2.(hc));
  t.count <- t.count + 1

let copy t = { t with contents=Array.copy t.contents; count=t.count }

let rec chain_find x =
  function
    | Chain(a,b,c) -> if Pervasives.(=) x a then b else chain_find x c 
    | Empty -> raise Not_found

let rec chain_length =
  function
    | Chain(a,b,c) -> 1 + chain_length c
    | Empty -> 0

let rec chain_mem x =
  function
    | Chain(a,b,c) -> (Pervasives.(=) x a) or chain_mem x c 
    | Empty -> false

let rec chain_fold f x acc =
  match x with
  | Chain(a,b,c) -> f a b (chain_fold f c acc)
  | Empty -> acc

let rec chain_remove x =
  function
    | Chain(a,b,c) -> if Pervasives.(=) x a then c else Chain(a,b,chain_remove x c)
    | Empty -> Empty

let find t x = 
  let arr = t.contents in 
  let hc = norm (hash x) mod (Array.length arr) in 
  chain_find x arr.(hc)

let rec chain_find_all x y = 
  match y with 
    Empty -> []
  | Chain(x2,y,t) -> if Pervasives.(=) x x2 then y::chain_find_all x t else chain_find_all x t

let find_all t x = 
  let arr = t.contents in 
  let hc = norm (hash x) mod (Array.length arr) in 
  chain_find_all x  arr.(hc)

let mem t x =
  let arr = t.contents in 
  let hc = norm (hash x) mod (Array.length arr) in 
  let b = arr.(hc) in 
(*   if chain_length b > 8 then prerr_endline ("chain length = "^string_of_int (chain_length b)^", #entries.count = "^string_of_int t.count^", hash-code = "^string_of_int hc^", #buckets = "^string_of_int (Array.length t.contents)^ ((*IF-FSHARP (box (match b with Chain(a,_,_) -> a)).ToString() ENDIF-FSHARP*) (""))); *)
  chain_mem x b

let remove t x = 
  let arr = t.contents in 
  let hc = norm (hash x) mod (Array.length arr) in 
  arr.(hc) <- chain_remove x arr.(hc);
  t.count <- t.count - 1

let replace t x y = 
  let arr = t.contents in 
  let hc = norm (hash x) mod (Array.length arr) in 
  arr.(hc) <- Chain(x,y,chain_remove x arr.(hc))

let fold f t c = 
  let arr = t.contents in 
  Array.fold_right (chain_fold f) arr c




