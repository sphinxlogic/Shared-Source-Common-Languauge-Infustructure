(* (c) Microsoft Corporation. All rights reserved *)

type fpclass = FP_normal | FP_subnormal| FP_zero| FP_infinite | FP_nan      
(* type 'a ref = { mutable contents: 'a } *)
type stream = System.IO.Stream 
type binary_writer = System.IO.BinaryWriter
type text_writer = System.IO.TextWriter
type stream_writer = System.IO.StreamWriter
type binary_formatter = System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
type writer = 
  | StreamWriter of stream_writer
  | TextWriter of text_writer
  | BinaryWriter of binary_writer
type out_channel = OutChannel of writer ref
type open_flag =
  | Open_rdonly | Open_wronly | Open_append
  | Open_creat | Open_trunc | Open_excl
  | Open_binary | Open_text | Open_nonblock
type binary_reader = System.IO.BinaryReader
type stream_reader = System.IO.StreamReader
type text_reader = System.IO.TextReader

type reader = 
  | StreamReader of stream_reader
  | TextReader of text_reader
  | BinaryReader of binary_reader
type in_channel = InChannel of reader ref
exception Exit

let raise (e:exn) = (# "throw" e : 'a)

let invalid_arg s = raise (Invalid_argument s)
let failwith s = raise (Failure s)

let box (x:'a) = (# "box !0" type ('a) x : obj)
let unbox (x:obj) = (# "unbox.any !0" type ('a) x : 'a)
let nonnull (x:'a) = (# "ldnull cgt.un" (box x) : bool)
let cast (x:'a) = unbox (box x)
let upcast (x:'a) = unbox (box x)
let downcast (x:'a) = unbox (box x)

let (=) (x : 'a) (y : 'a) = (# "ldc.i4 0 ceq" (inbuilt_poly_compare x y) : bool )
 when 'a = bool = (# "ceq" x y : bool )
 when 'a = int = (# "ceq" x y : bool )
 when 'a = sbyte = (# "ceq" x y : bool )
 when 'a = int16 = (# "ceq" x y : bool )
 when 'a = int32 = (# "ceq" x y : bool )
 when 'a = int64 = (# "ceq" x y : bool )
 when 'a = byte = (# "ceq" x y : bool )
 when 'a = uint16 = (# "ceq" x y : bool )
 when 'a = uint32 = (# "ceq" x y : bool )
 when 'a = uint64 = (# "ceq" x y : bool )
 when 'a = float = (# "ceq" x y : bool )
 when 'a = char = (# "ceq" x y : bool )
 when 'a = string = (# "call instance bool [.assembly extern mscorlib {.publickeytoken = (B7 7A 5C 56 19 34 E0 89 )  }  ]System.String:: Equals(string)" x y : bool)

let int_neg (x:int) = (# "neg" x : int) 

let not (b:bool) = (# " ldc.i4 1 xor" b : bool)
let compare (x : 'a) (y : 'a) = (inbuilt_poly_compare x y)
 when 'a = bool = (# "sub" x y : int )
 when 'a = sbyte = (# "sub" x y : int )
 when 'a = int16 = (# "sub" x y : int )
 when 'a = int32 = if (# "clt" x y : bool ) then (-1) else (# "cgt" x y : int )
 when 'a = int = if (# "clt" x y : bool ) then (-1) else (# "cgt" x y : int )
 when 'a = int64 = if (# "clt" x y : bool ) then (-1) else (# "cgt" x y : int )
 when 'a = byte = (# "sub" x y : int )
 when 'a = uint16 = (# "sub" x y : int )
 when 'a = uint32 = if (# "clt.un" x y : bool ) then (-1) else (# "cgt.un" x y : int )
 when 'a = uint64 = if (# "clt.un" x y : bool ) then (-1) else (# "cgt.un" x y : int )
 when 'a = float = if (# "clt" x y : bool ) then (-1) else (# "cgt" x y : int )
 when 'a = char = (# "sub" x y : int )
 when 'a = string = (# "call instance int32 [.assembly extern mscorlib {.publickeytoken = (B7 7A 5C 56 19 34 E0 89 )  }  ]System.String:: CompareTo(string)" x y : int)

let (<>) (x:'a) (y:'a) = (# "ldc.i4 1 xor" (x = y) : bool)
 when 'a = bool = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = int = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = sbyte = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = int16 = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = int32 = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = int64 = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = byte = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = uint16 = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = uint32 = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = uint64 = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = float = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = char = (# "ceq ldc.i4 1 xor" x y : bool )
 when 'a = string = (# "call instance bool [.assembly extern mscorlib {.publickeytoken = (B7 7A 5C 56 19 34 E0 89 )  }  ]System.String:: Equals(string) ldc.i4 1 xor" x y : bool)

let (<) (x:'a) (y:'a) = (# "ldc.i4 0 clt" (compare x y) : bool)
 when 'a = bool = (# "clt" x y : bool )
 when 'a = int = (# "clt" x y : bool )
 when 'a = sbyte = (# "clt" x y : bool )
 when 'a = int16 = (# "clt" x y : bool )
 when 'a = int32 = (# "clt" x y : bool )
 when 'a = int64 = (# "clt" x y : bool )
 when 'a = byte = (# "clt.un" x y : bool )
 when 'a = uint16 = (# "clt.un" x y : bool )
 when 'a = uint32 = (# "clt.un" x y : bool )
 when 'a = uint64 = (# "clt.un" x y : bool )
 when 'a = float = (# "clt" x y : bool )
 when 'a = char = (# "clt" x y : bool )

let (>) (x:'a) (y:'a) = (# "cgt" (compare x y) 0 : bool)
 when 'a = bool = (# "cgt" x y : bool )
 when 'a = int = (# "cgt" x y : bool )
 when 'a = sbyte = (# "cgt" x y : bool )
 when 'a = int16 = (# "cgt" x y : bool )
 when 'a = int32 = (# "cgt" x y : bool )
 when 'a = int64 = (# "cgt" x y : bool )
 when 'a = byte = (# "cgt.un" x y : bool )
 when 'a = uint16 = (# "cgt.un" x y : bool )
 when 'a = uint32 = (# "cgt.un" x y : bool )
 when 'a = uint64 = (# "cgt.un" x y : bool )
 when 'a = float = (# "cgt" x y : bool )
 when 'a = char = (# "cgt" x y : bool )
let (<=) (x:'a) (y:'a) = (# "cgt ldc.i4 1 xor" (compare x y) 0 : bool)
 when 'a = bool = (# "cgt ldc.i4 1 xor" x y : bool )
 when 'a = int = (# "cgt ldc.i4 1 xor" x y : bool )
 when 'a = sbyte = (# "cgt ldc.i4 1 xor" x y : bool )
 when 'a = int16 = (# "cgt ldc.i4 1 xor" x y : bool )
 when 'a = int32 = (# "cgt ldc.i4 1 xor" x y : bool )
 when 'a = int64 = (# "cgt ldc.i4 1 xor" x y : bool )
 when 'a = byte = (# "cgt.un ldc.i4 1 xor" x y : bool )
 when 'a = uint16 = (# "cgt.un ldc.i4 1 xor" x y : bool )
 when 'a = uint32 = (# "cgt.un ldc.i4 1 xor" x y : bool )
 when 'a = uint64 = (# "cgt.un ldc.i4 1 xor" x y : bool )
 when 'a = float = (# "cgt ldc.i4 1 xor" x y : bool )
 when 'a = char = (# "cgt ldc.i4 1 xor" x y : bool )

let (>=) (x:'a) (y:'a) = not (x < y)
 when 'a = bool = (# "clt ldc.i4 1 xor" x y : bool )
 when 'a = int = (# "clt ldc.i4 1 xor" x y : bool )
 when 'a = sbyte = (# "clt ldc.i4 1 xor" x y : bool )
 when 'a = int16 = (# "clt ldc.i4 1 xor" x y : bool )
 when 'a = int32 = (# "clt ldc.i4 1 xor" x y : bool )
 when 'a = int64 = (# "clt ldc.i4 1 xor" x y : bool )
 when 'a = byte = (# "clt.un ldc.i4 1 xor" x y : bool )
 when 'a = uint16 = (# "clt.un ldc.i4 1 xor" x y : bool )
 when 'a = uint32 = (# "clt.un ldc.i4 1 xor" x y : bool )
 when 'a = uint64 = (# "clt.un ldc.i4 1 xor" x y : bool )
 when 'a = float = (# "clt ldc.i4 1 xor" x y : bool )
 when 'a = char = (# "clt ldc.i4 1 xor" x y : bool )

let min x y = if x < y then x else y
let max x y = if x < y then y else x
let (==) (x: 'a)  (y: 'a) = inbuilt_poly_eq x y
 when 'a = bool = (# "ceq" x y : bool )
 when 'a = int = (# "ceq" x y : bool )
 when 'a = sbyte = (# "ceq" x y : bool )
 when 'a = int16 = (# "ceq" x y : bool )
 when 'a = int32 = (# "ceq" x y : bool )
 when 'a = int64 = (# "ceq" x y : bool )
 when 'a = byte = (# "ceq" x y : bool )
 when 'a = uint16 = (# "ceq" x y : bool )
 when 'a = uint32 = (# "ceq" x y : bool )
 when 'a = uint64 = (# "ceq" x y : bool )
 when 'a = float = (# "ceq" x y : bool )
 when 'a = char = (# "ceq" x y : bool )
let (!=) (x:'a) (y:'a) = not (x == y)

let succ (x:int) = (# "ldc.i4 1 add" x : int)
let pred (x:int) = (# "ldc.i4 1 sub" x : int)
let (+) (x:int) (y:int) = (# "add" x y : int)
let (-) (x:int) (y:int) = (# "sub" x y : int)
let ( * ) (x:int) (y:int) = (# "mul" x y : int)
let (/) (x:int) (y:int) = (# "div" x y : int)
let (mod) (x:int) (y:int) = (# "rem.un" x y : int)
let (land) (x:int) (y:int) = (# "and" x y : int)
let (lor) (x:int) (y:int) = (# "or" x y : int)
let (lxor) (x:int) (y:int) = (# "xor" x y : int)
let lnot (x:int) = (# "not" x : int)
let (lsl) (x:int) (y:int) = (# "shl" x y : int)
let (lsr) (x:int) (y:int) = (# "shr" x y : int)
let (asr) (x:int) (y:int) = (# "shr.un" x y : int)
let abs (x:int) = if x < 0 then int_neg x else x
let max_int = 2147483647
let min_int = int_neg 2147483648

(* let (~-.) (x:float) =  (# "neg" x : float) *)
let (+.) (x:float) (y:float) =  (# "add" x y : float)
let (-.) (x:float) (y:float) =  (# "sub" x y : float)
let ( *.) (x1:float) (y1:float) =  (# "mul" x1 y1 : float)
let ( /.) (x:float) (y:float) =  (# "div" x y : float)

let ( ** ) (x:float) (y:float) =  System.Math.Pow(x,y)
let sqrt (x:float) = System.Math.Sqrt(x)
let exp (x:float) = System.Math.Exp(x)
let log (x:float) = System.Math.Log(x)
let log10 (x:float) = System.Math.Log10(x)
let cos (x:float) = System.Math.Cos(x)
let sin (x:float) = System.Math.Sin(x)
let tan (x:float) = System.Math.Tan(x)
let acos (x:float) = System.Math.Acos(x)
let asin (x:float) = System.Math.Asin(x)
let atan (x:float) = System.Math.Atan(x)
let atan2 (x:float) (y:float) = System.Math.Atan2(x,y)
let cosh (x:float) = System.Math.Cosh(x)
let sinh (x:float) = System.Math.Sinh(x)
let tanh (x:float) = System.Math.Tanh(x)
let ceil (x:float) = System.Math.Ceiling(x)
let floor (x:float) = System.Math.Floor(x)
let abs_float (x:float) = System.Math.Abs(x)
let mod_float (x:float) (y:float) = System.Math.IEEERemainder(x,y)

let float (x:int) =  (# "conv.r8" x : float)
let float_of_int (x:int) =  (# "conv.r8" x : float)

(* TODO: implement this *)
let frexp (x : float) = (failwith "frexp: unimplemented" : float * int)

(* TODO: more efficient version of this *)
let ldexp x n = x *. (2.0 ** float_of_int n)
let modf x = let integral = floor x in (integral, x -. integral)
let truncate (x:float) =  System.Convert.ToInt32(x)
let int_of_float x =  truncate x

let infinity = (# "ldc.r8 float64(0x7FF0000000000000)" : float)
let neg_infinity = (# "ldc.r8 float64(0xFFF0000000000000)" : float)
let nan = (# "ldc.r8 float64(0xFFF8000000000000)" : float)


(* TODO: subnormal never returned *)
let classify_float (x:float) = 
  if System.Double.IsNaN(x) then FP_nan
  else if System.Double.IsNegativeInfinity(x) then FP_infinite
  else if System.Double.IsPositiveInfinity(x) then FP_infinite
  else if x = 0.0 then FP_zero
  else FP_normal
       
let (^) (x:string) (y:string) = System.String.Concat(x,y)

let int_of_char (c:char) = (# "" c : int)
let char_of_int (i:int) = if i > 255 then invalid_arg "char_of_int" else if i < 0 then invalid_arg "char_of_int: negative" else  (# "" i : char)
let ignore x = ()
let string_of_bool b = if b then "true" else "false"
let bool_of_string s = if s = "true" then true else if s = "false" then false else invalid_arg "bool_of_string"

let fst (x,y) = x
let snd (x,y) = y

let ref x = { contents=x }
let (!) x = x.contents
let (:=) x y = x.contents <- y

let any_to_string (x: 'a) = (box x).ToString() 

let string_of_int (x:int) = any_to_string x
let int_of_string (s:string) = System.Int32.Parse(s)
let string_of_float (x:float) = any_to_string x
let float_of_string (s:string) = System.Double.Parse(s)

let nonempty x = match x with [] -> false | _ -> true

(* let rec (@) x y = match x with [] -> y | (h::t) -> h :: (t @ y)*)
let (@) l1 l2 = 
  match l1 with
  | [] -> l2
  | (h::t) -> 
  match l2 with
  | [] -> l1
  | _ -> 
      let res = [h] in 
      let mutable curr = t in 
      let mutable cell = res in 
      while nonempty curr do
	let nw = [curr.(::).0] in 
	cell.(::).1 <- nw;
	curr <- curr.(::).1;
	cell <- nw
      done;
      cell.(::).1 <- l2;
      res

let (!!) (OutChannel os) = !os
let (<--) (OutChannel os) os' = os := os'

let get_stdout () = System.Console.Out
let get_stderr () = System.Console.Error
let stdout =  OutChannel (ref (TextWriter (get_stdout ())))
let stderr =  OutChannel (ref (TextWriter (get_stderr ())))

let stream_to_binary_writer (s:stream) = BinaryWriter (new System.IO.BinaryWriter(s))
let stream_to_stream_writer (s:stream) =   StreamWriter (new System.IO.StreamWriter(s))

let rec mem x l = match l with [] -> false | h::t -> if x = h then true else mem x t

let open_out_gen flags (perm:int) (s:string) = 
  (* TODO: permissions are ignored *)
  let access = 
    match mem Open_rdonly flags, mem Open_wronly flags with
      true, true -> invalid_arg "open_out_gen: access"
    | true, false -> invalid_arg "open_out_gen: invalid access for writing" (* System.IO.FileAccess.Read *)
    | false, true -> System.IO.FileAccess.Write
    | false, false -> System.IO.FileAccess.ReadWrite  in 
  let mode =
    match mem Open_excl flags,mem Open_append flags, mem Open_creat flags, mem Open_trunc flags with
    | true,false,false,false -> System.IO.FileMode.CreateNew
    | false,false,true,false -> System.IO.FileMode.Create
    | false,false,false,false -> System.IO.FileMode.OpenOrCreate
    | false,false,false,true -> System.IO.FileMode.Truncate
    | false,true,false,false -> System.IO.FileMode.Append
    | _ -> invalid_arg "open_out_gen: mode" in 
  let share = System.IO.FileShare.Read in 
  let buf_size = 0x1000 in 
  let allow_async = mem Open_nonblock flags in 
  let stream = (upcast (new System.IO.FileStream(s,mode,access,share,buf_size,allow_async)) : System.IO.Stream) in
  match mem Open_binary flags, mem Open_text flags with 
  | true,true -> invalid_arg "open_out_gen: text/binary"
  | true,false -> OutChannel (ref (stream_to_binary_writer stream ))
  | false,true | false,false -> OutChannel (ref (stream_to_stream_writer stream))
  
let open_out (s:string) = open_out_gen [Open_text; Open_wronly; Open_creat] 777 s
let open_out_bin (s:string) = open_out_gen [Open_binary; Open_wronly; Open_creat] 777 s

let flush os = 
  match !!os with 
  | TextWriter tw -> tw.Flush()
  | BinaryWriter bw -> bw.Flush()
  | StreamWriter sw -> sw.Flush()

let close_out os = 
  match !!os with 
  | TextWriter tw -> tw.Close()
  | BinaryWriter bw -> bw.Close()
  | StreamWriter sw -> sw.Close()

let output_string os (s:string) = 
  match !!os with 
  | TextWriter tw -> tw.Write(s)
  | BinaryWriter bw -> bw.Write(s)
  | StreamWriter sw -> sw.Write(s)

let output_char os (c:char) = 
  match !!os with 
  | TextWriter tw -> tw.Write(c)
  | BinaryWriter bw -> bw.Write(c)
  | StreamWriter sw -> sw.Write(c)

let out_channel_to_stream os =
  match !!os with 
  | TextWriter tw -> failwith "cannot seek, set position or calculate length of this stream"
  | BinaryWriter bw -> (cast bw.BaseStream : System.IO.Stream)
  | StreamWriter sw -> (cast sw.BaseStream : System.IO.Stream)

let int_to_int64 (n:int) = (# "conv.i8" n : int64)
let int64_to_int (n:int64) = (# "conv.i4" n : int)

let seek_out os (n:int) = 
  ignore((out_channel_to_stream os).Seek(int_to_int64 n,System.IO.SeekOrigin.Begin))

let pos_out os = int64_to_int (out_channel_to_stream os).Position
let out_channel_length os = int64_to_int (out_channel_to_stream os).Length

let output (os:out_channel) (buf: byte[]) (x:int) (len: int) = (out_channel_to_stream os).Write(buf,x,len)

let byte_to_int (x:byte) = (# "" x : int)
let int_to_byte (x:int) = (# "" x : byte)
let int_to_char (x:int) = (# "" x : char)

let output_byte os (x:int) = 
  match !!os with 
  | TextWriter tw ->  tw.Write(int_to_char (x mod 256))
  | BinaryWriter _  | StreamWriter _ -> (out_channel_to_stream os).WriteByte(int_to_byte x)

let output_binary_int os (x:int) = 
  match !!os with 
  | BinaryWriter bw -> bw.Write(x)
  | _ -> failwith "output_binary_int: not a binary stream"

let set_binary_mode_out os b = 
  match !!os with 
  | StreamWriter _ when not b -> ()
  | BinaryWriter _ when b -> ()
  | BinaryWriter bw -> os <--  stream_to_stream_writer (out_channel_to_stream os)
  | StreamWriter bw -> os <-- stream_to_binary_writer (out_channel_to_stream os)
  | TextWriter _ when b -> failwith "cannot set this stream to binary mode"
  | TextWriter _ -> ()

let print_string (s:string) = System.Console.Write(s)
let print_newline () = System.Console.WriteLine()
let print_int (x:int) = System.Console.Write(x)
let print_float (x:float) = System.Console.Write(x)
let print_endline (s:string) = System.Console.WriteLine(s)
let print_char (c:char) = System.Console.Write(c)

let output_value os (x: 'a) = 
  let formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter() in
  formatter.Serialize(out_channel_to_stream os,box x)

let prerr_int (x:int) = (get_stderr()).Write(x)
let prerr_float (x:float) = (get_stderr()).Write(x)
let prerr_string (x:string) = (get_stderr()).Write(x)
let prerr_endline (x:string) = (get_stderr()).WriteLine(x)
let prerr_newline () = (get_stderr()).WriteLine()
let prerr_char (c:char) = (get_stderr()).Write(c)

let (!!!) (InChannel isref) = !isref
let (<---) (InChannel isref) is' = isref := is'

let get_stdin () = System.Console.In
let stdin = InChannel (ref (TextReader (get_stdin())))

let stream_to_binary_reader (s:stream) = BinaryReader (new System.IO.BinaryReader(s))
let stream_to_stream_reader (s:stream) = StreamReader (new System.IO.StreamReader(s))

(* TODO: permissions are ignored *)
let open_in_gen flags (perm:int) (s:string) = 
  let access = 
    match mem Open_rdonly flags, mem Open_wronly flags with
    | true, true -> invalid_arg "open_in_gen: access"
    | true, false -> System.IO.FileAccess.Read 
    | false, true -> invalid_arg "open_in_gen: invalid access for reading"
    | false, false -> System.IO.FileAccess.ReadWrite in 
  let mode = 
    match mem Open_excl flags,mem Open_append flags, mem Open_creat flags, mem Open_trunc flags with
    | false,false,false,false -> System.IO.FileMode.Open
    | _ -> invalid_arg "open_in_gen: invalid mode for reading" in
  let share = System.IO.FileShare.Read in 
  let buf_size = 0x1000 in 
  let allow_async = mem Open_nonblock flags in 
  let stream = (upcast (System.IO.FileStream(s,mode,access,share,buf_size,allow_async)) : System.IO.Stream) in 
  match mem Open_binary flags, mem Open_text flags with 
    true,true -> invalid_arg "open_in_gen: text/binary"
  | true,false -> InChannel (ref (stream_to_binary_reader stream ))
  | false,true | false,false -> InChannel (ref (stream_to_stream_reader stream))
	
let open_in (s:string) = open_in_gen [Open_text; Open_rdonly] 777 s
let open_in_bin (s:string) = open_in_gen [Open_binary; Open_rdonly] 777 s

let close_in is = 
  match !!!is with 
  | TextReader tw -> tw.Close()
  | BinaryReader bw -> bw.Close()
  | StreamReader sw -> sw.Close()

let input_line is = 
  match !!!is with 
  | BinaryReader bw -> failwith "input_line: binary mode"
  | TextReader tw -> tw.ReadLine()
  | StreamReader sw -> sw.ReadLine()

let input_byte is = 
  match !!!is with 
  | BinaryReader bw ->  byte_to_int (bw.ReadByte())
  | TextReader tw -> tw.Read()
  | StreamReader sw -> sw.Read()

let input_char is = char_of_int (input_byte is)

let in_channel_to_stream is =
  match !!!is with 
  | TextReader tw -> failwith "cannot seek, set position or calculate length of this stream"
  | BinaryReader bw -> bw.BaseStream
  | StreamReader sw -> sw.BaseStream

let seek_in is (n:int) = 
  ignore ((in_channel_to_stream is).Seek(int_to_int64 n,System.IO.SeekOrigin.Begin))

let pos_in is  = int64_to_int (in_channel_to_stream is).Position
let in_channel_length is  = int64_to_int (in_channel_to_stream is).Length

let input (is: in_channel) (buf: byte[]) (x:int) (len: int) = (in_channel_to_stream is).Read(buf,x,len)

let really_input is (buf: byte[]) (index:int) (count: int) = 
  let mutable n = 0 in 
  let mutable i = 1 in 
  while (if i > 0 then n < count else false) do 
    i <- input is buf (index + n) (count - n);
    n <- n + i
  done

let unsafe_really_input is buf x len = really_input is buf x len

let input_binary_int is = 
  match !!!is with 
  | BinaryReader bw -> bw.ReadInt32()
  | _ -> failwith "input_binary_int: not a binary stream"

let set_binary_mode_in is b = 
  match !!!is with 
  | StreamReader _ when not b -> ()
  | BinaryReader _ when b -> ()
  | BinaryReader bw -> is <---  stream_to_stream_reader (in_channel_to_stream is)
  | StreamReader bw -> is <--- stream_to_binary_reader (in_channel_to_stream is)
  | TextReader _ when b -> failwith "cannot set this stream to binary mode"
  | TextReader _ -> ()

let read_line () = System.Console.ReadLine()
let read_int () = (failwith "read_int: not implemented" : int) (* @todo *)
let read_float () = (failwith "read_float: not implemented" : float) (* @todo *)

let input_value is = 
  let formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter() in
  let res = formatter.Deserialize(in_channel_to_stream is) in 
  ((unbox res) : 'a)

let incr x = x.contents <- x.contents + 1
let decr x = x.contents <- x.contents - 1

let at_exits = ref (fun () -> ())
let do_at_exit () =  (!at_exits) (); at_exits := (fun () -> ())
let exit (n:int) = do_at_exit(); System.Environment.Exit(n); failwith "exit failure"
let at_exit (f : unit -> unit) = let old = !at_exits in at_exits := (fun () -> old (); f ())

(* WARNING - Do not use these as _values_ before this point *) 
let (&&) x y = if x then y else false
let (&) x y = if x then y else false
let (||) x y = if x then true else y
let (or) x y = if x then true else y

let isnull (x:'a) = not (nonnull x)
let null () = (unbox (# "ldnull" : obj) : 'a)
