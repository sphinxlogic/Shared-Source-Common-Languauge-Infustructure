(* (c) Microsoft Corporation. All rights reserved *)
let length (s:string) =  s.Length

(* TODO: raise Invalid_argument if out of range.  Do this by making Invalid_argument *)
(* identical to the error raised by stelem.u1?? *)
let get (s:string) (n:int) = s.get_Chars(n)

let of_char (c:char) = System.Char.ToString(c)


(* TODO: better implementation of this *)
let concat sep (strings : string list) =  
  match strings with
    [] -> "" 
  | [h] -> h
  | h :: t -> List.fold_left (fun s x -> s^sep^x) h t

let sub (s:string) (start:int) (len:int) =  s.Substring(start,len)

let iter (f : (char -> unit)) (s:string) =
  for i = 0 to length s - 1 do f (get s i) done
  
let index_from (s:string) (start:int) (c:char) =  
  let r = s.IndexOf(c,start) in if r = -1 then raise Not_found else r
let rindex_from (s:string) (start:int) (c:char) =  
  let r =  s.LastIndexOf(c,start) in if r = -1 then raise Not_found else r

let index (s:string) (c:char) =  index_from s 0 c
let rindex (s:string) (c:char) =  rindex_from s (length s - 1) c

let contains_between (s:string) (start:int) (stop:int) (c:char) =  
  s.IndexOf(c,start,(stop-start+1)) <> -1

let contains_from (s:string) (start:int) (c:char) =  contains_between s start (length s - 1) c
let rcontains_from (s:string) (finish:int) (c:char) =  contains_between s 0 finish c
let contains (s:string) (c:char) =  contains_from s 0 c

let uppercase (s:string) =  s.ToUpper()
let lowercase (s:string) =  s.ToLower()

let capitalize (s:string) =  
  if length s = 0 then raise (Invalid_argument "capitalize");
  concat "" [uppercase (sub s 0 1); sub s 1 (length s - 1)]

let uncapitalize (s:string) =  
  if length s = 0 then raise (Invalid_argument "uncapitalize");
  concat "" [lowercase (sub s 0 1); sub s 1 (length s - 1)]

(*
TODO: encodings.

let to_mutstring (s:string) =  (failwith "to_mutstring: unimplemented" : mutstring)
let of_mutstring (s:mutstring) =  (failwith "of_mutstring : unimplemented" : string)
*)

(*    (# "call string [.assembly extern mscorlib {.publickeytoken = (B7 7A 5C 56 19 34 E0 89 )   }  ]System.String::ToLower()" s : string) *)
