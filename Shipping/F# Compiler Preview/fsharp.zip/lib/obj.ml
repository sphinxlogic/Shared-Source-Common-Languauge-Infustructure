type t = obj
let repr x = Pervasives.box x
let obj x = Pervasives.unbox x
let magic x = obj (repr x)
let nullobj = (# "ldnull" : obj)
let null () = Pervasives.unbox (# "ldnull" : obj)

