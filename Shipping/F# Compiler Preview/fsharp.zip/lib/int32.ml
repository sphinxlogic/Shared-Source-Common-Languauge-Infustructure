(* (c) Microsoft Corporation. All rights reserved *)
let zero = (# "ldc.i4 0" : int32) 
let one = (# "ldc.i4 1" : int32) 
let minus_one = (# "ldc.i4 -1" : int32) 
let neg (x:int32) =  (# "neg" x : int32) 
let add (x:int32) (y:int32) = (# "add" x y : int32) 
let sub (x:int32) (y:int32) = (# "sub" x y : int32) 
let mul (x:int32) (y:int32) = (# "mul" x y : int32)
let div (x:int32) (y:int32) = (# "div" x y : int32)
let rem (x:int32) (y:int32) = (# "rem" x y : int32)
let succ (x:int32) = (# "ldc.i4 1 add" x : int32)
let pred (x:int32) = (# "ldc.i4 1 sub" x : int32)
let abs (x:int32) = if x < zero then neg x else x
let max_int = (# "ldc.i4 2147483647" : int32)
let min_int = (# "ldc.i4 -2147483648" : int32)
let logand (x:int32) (y:int32) = (# "and" x y : int32)
let logor (x:int32) (y:int32) = (# "or" x y : int32)
let logxor (x:int32) (y:int32) = (# "xor" x y : int32)
let lognot (x:int32) = (# "not" x : int32)
let shift_left (x:int32) (n:int) =  (# "shl" x n : int32)
let shift_right (x:int32) (n:int) =  (# "shr" x n : int32)
let shift_right_logical (x:int32) (n:int) =  (# "shr.un" x n : int32)
let of_int (n:int) =  n
let to_int (x:int32) = x
let of_float (f:float) =  (# "conv.i4" f : int32)
let to_float (x:int32) =  (# "conv.r8" x : float)
let of_string (s:string) = 
  if (String.length s >= 2 & s.[0] = '0' & s.[1] = 'x') then
    System.Int32.Parse(String.sub s 2 (String.length s - 2), System.Globalization.NumberStyles.AllowHexSpecifier)
  else 
    System.Int32.Parse s
let to_string (x:int32) = (box x).ToString()
