(* (c) Microsoft Corporation. All rights reserved *)
let argv = let a = System.Environment.GetCommandLineArgs() in Array.init (Arr.length a) (Arr.get a)
let file_exists  (s:string) = System.IO.File.Exists(s)
let remove (s:string) = System.IO.File.Delete(s)
let rename (s:string) (s2:string) = System.IO.File.Move(s,s2)

let getenv (s:string) =
  let res = System.Environment.GetEnvironmentVariable(s) in
  if nonnull res then res else (raise Not_found : string)

let command (s:string) = 
  let p = System.Diagnostics.Process.Start(s) in 
  p.WaitForExit();
  p.ExitCode

(* let time () = System.DateTime.Now.ToOADate()*)

let chdir (s:string) = System.IO.Directory.SetCurrentDirectory(s)
let getcwd () = System.IO.Directory.GetCurrentDirectory()
let interactive = ref false
