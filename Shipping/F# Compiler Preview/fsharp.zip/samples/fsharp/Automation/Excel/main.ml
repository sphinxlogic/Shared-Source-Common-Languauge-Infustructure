open System
open System.Reflection (* For Missing.Value and BindingFlags *)
open System.Runtime.InteropServices (* For COMException *)
open Excel

let _ = 
  Console.WriteLine ("Creating new Excel.Application");
  let app = new ApplicationClass() in 
  Console.WriteLine ("Making application visible");		
  app.Visible <- true;
  Console.WriteLine ("Getting the workbooks collection");
  let workbooks = app.Workbooks in
  Console.WriteLine ("Adding a new workbook");
		
  let workbook = workbooks.Add(box XlWBATemplate.xlWBATWorksheet) in 

  Console.WriteLine ("Getting the worksheets collection");
  let sheets = workbook.Worksheets in 
  
  let worksheet = (cast (sheets.get_Item(box 1)) : _Worksheet) in 
  Console.WriteLine ("Setting the value for cell");
  
  (* This puts the value 5 to the cell G1 *)
  let range1 = worksheet.get_Range(box "G1", box Missing.Value) in 
  range1.Value2 <- box 5;
		
  (* This sends a single dimension array to Excel *)
  let range2 = worksheet.get_Range(box "A1", box "E1") in 
  let array2 = Arr.init 5 (fun i -> i + 1) in 
  range2.Value2 <- box array2;

  (* This sends a two dimension array to Excel *)
  let range3 = worksheet.get_Range(box "A3", box "E6") in 
  let array3 = Arr2.init 4 5 (fun i j -> i*10 + j) in 
  range3.Value2 <- box array3;

  (* This reads a two dimension array from Excel *)
  let range4 = worksheet.get_Range(box "A3", box "E6") in
  let array4 = (cast range4.Value2 : obj[,]) in 

  Console.WriteLine ("Low: "^string_of_int(array4.GetLowerBound(0)));
  for i=array4.GetLowerBound(0) to array4.GetUpperBound(0) do
    for j=array4.GetLowerBound(1) to array4.GetUpperBound(1) do
      Console.WriteLine ("Compare "^string_of_int i^","^string_of_int j);
      if int_of_float (cast (Arr2.get array4 i j) : float) <> Arr2.get array3 (i-array4.GetLowerBound(0))  (j-array4.GetLowerBound(1)) then
	Console.WriteLine ("ERROR: Comparison FAILED!");
    done;
  done;

  (*  This fills two dimension array with points for two curves and sends it to Excel *)
  let range5 = worksheet.get_Range(box "A8", box "J9") in 
  let array5 = 
    Arr2.init 2 10
      (fun i j -> 
	let arg = (Math.PI /. 10.0) *. float_of_int j in 
	if i = 0 then Math.Sin(arg) else Math.Cos(arg)) in
  range5.Value2 <- box (array5 : float[,]);
		
  (* The following code would draw the chart if it wasn't for the Excel/CLR bug further below *)
  ignore (range5.Select());
  let chartobjects = (cast (worksheet.ChartObjects(box Missing.Value)) : ChartObjects) in 
  let chartobject = chartobjects.Add(10.0, 100.0, 450.0, 250.0) in 

(* The following call to get_Chart raises an exception and crashes Excel *)
(* at least for my (perhaps broken) local install of the CLR V1 *)
  let chart = (cast (chartobject.Chart) : _Chart) in  
  chart.ChartWizard(box range5,box XlChartType.xl3DColumn,box Missing.Value,box XlRowCol.xlRows,box Missing.Value,box Missing.Value,box true,box "Sample Chart",box "Sample Category Type",box "Sample Value Type",box Missing.Value);

  System.Threading.Thread.Sleep(1000);
  begin
    try 
   (*  If user interacted with Excel it will not close when the app object is destroyed, so we close it explicitely *)
      workbook.Saved <- true;
      app.UserControl <- false;
      app.Quit();
    with e -> Console.WriteLine ("User closed Excel manually, so we don't have to do that")
  end;
  Console.WriteLine ("Sample successfully finished!")
