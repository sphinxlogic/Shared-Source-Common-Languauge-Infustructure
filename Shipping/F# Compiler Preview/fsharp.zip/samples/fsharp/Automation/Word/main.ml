open System
open System.Diagnostics
open System.Runtime.InteropServices
open System.Reflection (* For Missing.Value *)
open System.Collections
open System.Threading
open Word

(* Automation APIs such as the Word COM object model are semi-typed, i.e. *)
(* many values are passed using the .NET type "object". *)
(* So we often use the F# "box" operation to produce a value of type *)
(* "object" from an arbitrary F# value.  "box" has type "'a -> obj". *)

(* Furthermore, many arguments are passed to the Word Automation API *)
(* "by reference", e.g. as the C# type &object.  In F# by-reference argument *)
(* "&T" appears as the F# type "T ref".  Thus many arguments are wrapped, *)
(* e.g. "ref x" or "ref (box x)". *)

(* Create a Word Appilcation and document. *)
let app = new Word.ApplicationClass()
let doc = new Word.DocumentClass()

(* Add some Autocorrect entries. *)
let autocorrect = app.AutoCorrect
let autoEntries = autocorrect.Entries 
let _ = autoEntries.Add("Inntroduction", "Introduction")

(* Count the number of open documents in the Word application. *)
let docs = app.Documents
let _ = Console.WriteLine (string_of_int docs.Count ^ " docs")

(* Show the application. *)
let _ = app.Visible <- true

(* The COM Word object model requires empty values in many places. *)
(* These are given the special value System.Reflection.Missing.Value. This *)
(* value is always passed by reference in this file, i.e. where values of *)
(* type "&object" are expected, so we make a byref location for it here. *)
(* Note that we assume that the COM API never writes into this byref *)
(* value. *)
let none = ref (box Missing.Value)

(* Add a document. *)
let doc2=docs.Add(none, none, none, none)

(* Add text to the doc.  This contains some deliberate misspellings so *)
(* that we can correct them below. *)
let _ =  
   let range = doc2.Range(none,none) in 
   range.Text <- "Microsoft Word Interoperability Sample\n\nInntroduction:\n\nMicrosoft .NET will alow the creation of truly distributed XML Web services. These services will integrate and collaborate with a range of complementary services to work for customers in ways that today's internet companies can only dream of. Microsoft .NET will drive the Next Generation Internet and will shift the focus from individual Web sites or devices connected to the Internet, to constellations of computers, devices, and services that work together to deliver broader, richer solutions.\nFor more info go to:\n   "
   (* Wait so the starting state can be admired*);
   Thread.Sleep(2000)

(* Format the title: for some reason this raises an exception on my *)
(* computer, both for the C# sample and the code below.  It might work *)
(* for you, so I've included the code below. *)
let _ = 
  try 
    Console.WriteLine("Formatting the title");
    let range=doc2.Range(ref (box 0), ref (box 40)) in
    let fc= new Word.FontClass() in
    fc.Size <- Convert.ToSingle(24.0);
    fc.Bold <- 1;
    fc.Color <- Word.WdColor.wdColorGray30;
    range.Font <- (cast fc : Word.Font);
    let range=doc2.Range(ref (box 40), ref (box 54)) in 
    let fc= new Word.FontClass() in
    fc.Size <- Convert.ToSingle(14.0); 
    range.Font <- (cast fc : Word.Font);
    (* Wait so the new formatting can be appreciated *)
    Thread.Sleep(3000)
  with e -> Console.WriteLine("font error: "^Printexc.to_string e)

(* Fix spelling mistakes *)
let _ = 
  autocorrect.ReplaceTextFromSpellingChecker <- true;
  (* Fix inntroduction*)
  let errEntry= autoEntries.Item(ref (box "Inntroduction")) in
  let myWords=doc2.Words in 
  let errRange= myWords.Item(7) in 
  errEntry.Apply(errRange);
  (* Add a caption to the window and get it back *)
  let myWindow = app.ActiveWindow in 
  myWindow.Caption <- "Managed Word execution from C# ";
  let  gotCaption = myWindow.Caption in 
  if (gotCaption.Equals("Managed Word execution from C# ")) then
      Console.WriteLine("Caption assigned and got back");
  Thread.Sleep(2000);
  (* List the spelling errors *)
  let pr1 = doc2.SpellingErrors in
  Console.WriteLine("Spelling errors count:" ^ string_of_int pr1.Count);
  for i=1 to pr1.Count do
    let rg = pr1.Item(i) in 
    Console.WriteLine(rg.Text);
    Thread.Sleep(2000);
  done;
  (* Define the selection object, find and replace text *)
  let mySelection = myWindow.Selection in 
  let myFind = mySelection.Find in 
  Console.WriteLine(myFind.Text);
  (*  Find "alow" and replace with "allow" *)
  begin 
    try
      ignore (myFind.Execute(ref (box "alow"),none,none,none,none,none,none,none,none,ref (box "allow"),none,none,none,none,none));
      Thread.Sleep(2000);
    with e -> Console.WriteLine("find error: "^Printexc.to_string e)
  end

(* Change the formatting of ".NET" *)
let _ = 
  begin 
    try
      let range=doc2.Range(ref (box 65), ref (box 69)) in 
      Console.WriteLine("The color of .NET is being changed");
      let fc= new Word.FontClass() in
      fc.Bold <- 16;
      fc.Color<- Word.WdColor.wdColorLavender; 
      range.Font<- (cast fc : Word.Font);
      Thread.Sleep(2000);
    with e -> Console.WriteLine("font error: "^Printexc.to_string e)
  end;
  (* Underline the selected text *)
  let range=doc2.Range(ref (box 65),ref (box 69)) in 
  range.Underline <- Word.WdUnderline.wdUnderlineDouble

(* Add hyperlink and follow the hyperlink*)
let _ = 
  let my_Hyperlinks = doc2.Hyperlinks in 
  (* Make the range past the end of all document text *)
  let myWindow = app.ActiveWindow in 
  let mySelection = myWindow.Selection in 
  mySelection.Start <- 9999;
  mySelection.End  <- 9999;
  let range = mySelection.Range in
  (* Add a hyperlink *)
  let myAddress = "http://go.microsoft.com/fwlink/?linkid=3269&clcid=0x409" in 
  Console.WriteLine("Adding hyperlink to the document");
  let my_Hyperlink1= my_Hyperlinks._Add(box range, ref (box myAddress), none) in
  app.ActiveWindow.Selection.InsertAfter("\n");
  Thread.Sleep(5000);
  (* Open a window to Hyperlink *)
  let ie = Process.Start("iexplore.exe", my_Hyperlink1.Address) in 
  (* Wait for a short spell to allow the page to be examined *)
  Thread.Sleep(10000);
  (* Close the browser first*)
  Console.WriteLine("Removing browser window");
  ie.Kill()

(* Display "The End" *)
let _ = 
  app.ActiveWindow.Selection.InsertAfter("\nThe End");
  app.ActiveWindow.Selection.Start <- 0;
  app.ActiveWindow.Selection.End <- 0;
  app.Activate();
  Thread.Sleep(5000)

(* Close Microsoft Word *)
let _ = 
   app.ActiveWindow.Close(ref (box Word.WdSaveOptions.wdDoNotSaveChanges),none);
   app.Quit(none, none, none)
