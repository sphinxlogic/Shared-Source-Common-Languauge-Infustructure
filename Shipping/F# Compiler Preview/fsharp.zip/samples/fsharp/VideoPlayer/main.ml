(* This program demonstrates using a classic COM object from F#. *)

open System
open System.Runtime.InteropServices

(* Collects the filename of an AVI to show then create an  *)
(* instance of the Quartz classic COM object.  To show the AVI, the program calls *)
(* RenderFile and Run on IMediaControl.  Quartz uses its own thread and window *)
(* to display the AVI.  The main thread blocks on a ReadLine until the user hits *)
(* enter.  *)

let process file =
  let t = Threading.Thread.CurrentThread in
  t.ApartmentState <- Threading.ApartmentState.STA;
  let mc = new QuartzTypeLib.FilgraphManagerClass() in  (* QuartzTypeLib.IMediaControl *)
  begin
    try
      mc.RenderFile(file);
      mc.Run();
    with  e -> prerr_endline (Printexc.to_string e)
  end;
  Console.WriteLine("Hit Enter to continue/exit.");
  let _ = Console.ReadLine() in 
  ()

let _ = if Sys.argv.Length = 1 then Console.WriteLine ("play [file1.avi [file2.avi ...] ]")
let _ = Arg.parse [] process "play [file1.avi [file2.avi ...] ]"


