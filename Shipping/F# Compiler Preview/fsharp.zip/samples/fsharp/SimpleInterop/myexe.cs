
// This file demonstrates how to write a C# application which is 
// a client of an F# assembly. We call one of the published functions, 
// we create F# data values, we call an F# function that accepts 
// a delegate value as an argument and we discriminate over the 
// data produced as a result. 

class Tester {
   static void Main() { 
      System.Console.WriteLine("Testing interop between F# and C#");
      Mydll.loop(10); 
      Mydll.mydata x1 = Mydll.mydata.MkA();
      Mydll.mydata x2 = Mydll.mydata.MkB(3,x1);
      Mydll.mydata x3 = Mydll.mydata.MkB(2,x2);
      Mydll.mydata x4 = Mydll.mydata.MkB(1,x3);
      Mydll.mydataPrint(x4);

      // If the ML assembly were compiled with support for generics assumed
      // we could just use:
      //    Mydll.mydata x5 = Mydll.mydataMap(new System.Func(square), x4);

      Mydll.mydata x5 = Mydll.mydataMap(new System.Func(square), x4);

      Mydll.mydataPrint(x5);

      if (x5.IsB())
         System.Console.WriteLine("Correct!");
     
   }

   // If the ML assembly were compiled with support for generics assumed
   // we would just use:
   //     static int square(int x) { return x * x; }

   static object square(object x) { return (int) x * (int) x; }
}


