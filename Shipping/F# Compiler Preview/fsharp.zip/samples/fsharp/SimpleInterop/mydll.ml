(* This file is written in F# and defines a software component *)
(* which publishes some simple types and functions.  These can *)
(* then be packaged as a DLL which defines a .NET assembly. *)
(* The types and functions can then be accessed from any .NET *)
(* language. *)

(* Note that the function mydataMap accepts a function value *)
(* as an argument.  A delegate value can be passed where such a *)
(* function value is expected. *)

let rec loop n = 
   if n <= 0 then () else begin
     print_endline (string_of_int n);
     loop (n-1)
   end

type mydata = A | B of int * mydata

let rec mydataPrint d = 
   match d with 
   | A -> print_endline "the end!"
   | B (n,d) -> print_endline (string_of_int n); mydataPrint d

let rec mydataMap f d = 
   match d with 
   | A -> A
   | B (n,d) -> B (f n,mydataMap f d)



