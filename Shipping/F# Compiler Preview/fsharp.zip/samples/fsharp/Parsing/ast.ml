
type prog = Prog of stmt list

and stmt = 
  | Assign of string * string
  | While of string * stmt
  | Seq of stmt list
  | IfThen of string * stmt
  | IfThenElse of string * stmt * stmt
