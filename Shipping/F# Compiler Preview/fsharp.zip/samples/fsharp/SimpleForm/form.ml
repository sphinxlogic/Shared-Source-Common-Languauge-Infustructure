
open System
open System.Windows.Forms

let form = new Form()

let _ = form.Text <- "1st F# App"
let menu = form.Menu <- new MainMenu()
let mnuFile = form.Menu.MenuItems.Add("&File")
let mnuiSayHelloI = new MenuItem("&Say Hello", 
                                  new EventHandler(fun sender e -> form.Text <- "Hello"), 
                                  Shortcut.CtrlH)
let mnuiSayHello = mnuFile.MenuItems.Add(mnuiSayHelloI)
 
let _ = Application.Run(form)
