(* Game of life *)

open List

let prev sz i = if i = 0 then sz-1 else i-1 
let next sz i = if i = sz-1 then 0 else i+1
let neighbours sz (i,j) =
  [ (prev sz i,prev sz j); (prev sz i,j); (prev sz i,next sz j);
    (i,        prev sz j);                (i,        next sz j);
    (next sz i,prev sz j); (next sz i,j); (next sz i,next sz j)]

type cell =
    { x: int; y : int;
      mutable neighbours:  cell array;
      mutable count: int;  
      mutable alive: bool }

let mk_world size init = 
  let dummy_cell = { x=0;y=0; neighbours= [| |]; count=0; alive=false; } in 
  (* First make all the cells *)
  let grid = Array.create_matrix size size dummy_cell in 
  let get_cell (x,y) = grid.(x).(y) in
  for i = 0 to size - 1 do
    for j = 0 to size - 1 do 
      grid.(i).(j) <- { x=i;y=j; neighbours= [| |]; count=0; alive=false; } 
    done;
  done;
  (* Now record the neighbours of each cell. *)
  for i = 0 to size - 1 do
    for j = 0 to size - 1 do 
      (get_cell (i,j)).neighbours <- Array.of_list (map get_cell (neighbours size (i,j)))
    done;
  done;
  (* Set each cell in the initial list to "live" *)
  iter (fun p -> (get_cell p).alive <- true) init;
  (* Return ths array of live cells. *)
  Array.of_list (map get_cell init)

let mk_nextgen living =
  let n = Array.length living in
  (* For each living cell or neighbour of a living cell, set the count to 0 *)
  for i = 0 to n-1 do
    let c1 = living.(i) in 
    c1.count <- 0;
    let nbs = c1.neighbours in 
    for j = 0 to 7 do
      nbs.(j).count <- 0;
    done;
  done;
  (* Now compute the number of neighbours for these cells *)
  for i = 0 to n-1 do
    let nbs = living.(i).neighbours in 
    for j = 0 to 7 do
      let nb = nbs.(j)in 
      nb.count <- nb.count + 1;
    done;
  done;
  (* Now compute which cells live/die *)
  (* nb. "let mutable" is an F#-only extension to the Caml language *)
  (* You could instead use "let born = ref []".  In pure Caml only *)
  (* fields of records can be directly mutable, not local variables. *)
  let mutable born = [] in 
  let mutable died = [] in 
  let mutable alive = [] in 
  for i = 0 to n-1 do
    let c1 = living.(i) in 
    if c1.count = 2 or c1.count = 3 then alive <- c1::alive
    else (c1.alive <- false; died <- c1::died);
    let nbs = c1.neighbours in 
    for j = 0 to 7 do
      let nb = nbs.(j) in 
      if not nb.alive & nb.count = 3 then
	(nb.alive <- true; born <- nb::born; alive<-nb::alive)
    done;
  done;
  born, died, Array.of_list alive


let random_gen size = 
  let gen = System.Random() in
  let density = 0.05 +. (gen.NextDouble() *. 0.1) in
  let acc = ref [] in
  for i = 0 to size-1 do
    for j = 0 to size-1 do
      if gen.NextDouble() < density then acc:=(i,j)::(!acc);
    done;
  done;
  !acc

(* Compute the Game of Life and send the results to a client by *)
(* calling the given functions. *)
let life (set,clear,size) = 
  (* nb. We are considering adding an F#-only extension to the Caml language *)
  (* for more general "for" loops along the following lines. *)
  (*
    for alive = makeCells size (random_gen size) do
      let born,died,next = mk_nextgen prev in
      iter (fun c -> client.Clear(x,y)) died;
      iter (fun c -> client.Set(x,y)) born;
      alive <- next
    while (born <> [] or died <> [])
  *)

  let init = mk_world size (random_gen size) in  
  Array.iter (fun c -> set (c.x,c.y)) init;
  let rec display_next prev = 
    let born,died,next = mk_nextgen prev in
    List.iter (fun c -> clear (c.x,c.y)) died;
    List.iter (fun c -> set (c.x,c.y)) born;
    if (born <> [] or died <> []) then 
      display_next next in

  display_next init
  

