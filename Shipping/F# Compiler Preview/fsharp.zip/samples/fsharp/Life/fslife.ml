(* See Doc.html for details in this file *)

open Lazy
open System
open System.Windows.Forms
open System.IO
open System.Drawing
open System.Drawing.Drawing2D
open System.Drawing.Imaging
open System.ComponentModel

exception Interrupt

let backgroundColor = Color.Black
let liveColor = Color.HotPink
let refreshRate = 32
let magnification = 8
let displaySize = 64
let initialSize = 
  new System.Drawing.Size(magnification*displaySize,magnification*displaySize)

let interruptSemaphore = ref false
let exitSemaphore = ref false

let new_empty_bitmap () = 
  let bitmap = new Bitmap(displaySize,displaySize,PixelFormat.Format24bppRgb) in 
  for i = 0 to displaySize - 1 do
    for j = 0 to displaySize - 1 do
      bitmap.SetPixel(i,j,backgroundColor);
    done;
  done;
  bitmap

(* Given a plotting function, call the refresh function *)
(* on every 'refreshRate'th call to the plotting function. *)
let plotWithRefreshAtRefreshRate (plotter,refresher) =
  let numPlots = ref 0 in 
  (fun point -> 
    plotter point; 
    incr numPlots; 
    if !numPlots > refreshRate then (numPlots := 0; refresher()))

(* Given a plotting function, record the area touched by successive *)
(* calls to the plotting function and pass the cumulative extent of *)
(* the area to the refresh function every time it is called. *)
let refreshPlottedAreaOnly (plotter,refresher) =
  let maxX = ref 0 in 
  let maxY = ref 0 in 
  let minX = ref displaySize in 
  let minY = ref displaySize in 
  let plotter' (i,j) =
    if i > 0 & i<displaySize & j > 0 & j<displaySize then begin
      maxX := max i !maxX;
      minX := min i !minX;
      maxY := max j !maxY;
      minY := min j !minY;
      plotter (i,j)
    end in 
  let refresher' () = refresher (!minX,!minY,!maxX,!maxY) in 
  plotter', refresher'

(* Create and configure the bitmap, the form and *)
(* the menus used to control these. Note that the individual menus *)
(* can be referred to before they are specified, i.e. when adding the menus *)
(* to the menu bar.  This is the advantage of using the "let rec"/"lazy" *)
(* style used throughout this file - see Doc.thml for more details. *)
let rec bitmap'  = lazy (ref (new_empty_bitmap()))

(* Here is the brush used in painting the bitmap. *)
(* The cast is incldued because as usual the rest of the file *)
(* does not and should not care what kind of Brush this is. *)
and backgroundBrush' = lazy (cast (new SolidBrush(backgroundColor)) : Brush)

(* Create and configure the form, including adding the menus *)
and form' = lazy (new Form())
and act0' = 
  lazy ((force form').add_Closing
	  (new CancelEventHandler (fun sender e -> exitSemaphore := true)))
and act1' = 
  lazy ((force form').add_Paint
	  (new PaintEventHandler(fun sender (e : PaintEventArgs) -> 
	    let g = e.Graphics in 
	    let cliprect = e.ClipRectangle in 
	    g.FillRectangle((force backgroundBrush'), cliprect);
	    System.Console.WriteLine(box cliprect);
            g.DrawImage((cast !(force bitmap') : Image),cliprect,
			(cliprect.X)/magnification,
			(cliprect.Y)/magnification,
			(cliprect.Width)/magnification,        
			(cliprect.Height)/magnification,
			GraphicsUnit.Pixel) ;
	    g.Dispose())))
and act2' = lazy ((force form').Size <- initialSize)
and act3' = lazy ((force form').Text <- "Life")
and act4' = lazy ((force form').FormBorderStyle <- FormBorderStyle.FixedToolWindow)
and act5' = lazy ((force form').Menu <- new MainMenu())
and fileMenu' = lazy ((force form').Menu.MenuItems.Add("&File"))
and act6' = lazy ((force fileMenu').MenuItems.Add(force goMenuItem' : MenuItem))
and act7' = lazy ((force fileMenu').MenuItems.Add(force interruptMenuItem' : MenuItem))
and act8' = lazy ((force fileMenu').MenuItems.Add("-"))
and act9' = lazy ((force fileMenu').MenuItems.Add(new MenuItem("E&xit",
	  						       new EventHandler(fun sender e -> (force form').Close()), 
							       Shortcut.CtrlX)))

(* Here are the menu items. *)
and goMenuItem' = lazy
  (new MenuItem("&Go", 
	       new EventHandler(fun sender e -> go()),
	       Shortcut.CtrlG))
and interruptMenuItem' = lazy
  (new MenuItem("&Interrupt", 
	       new EventHandler(fun sender e -> interrupt()),
	       Shortcut.CtrlC))
and act10' = lazy ((force interruptMenuItem').Enabled <- false)

(* 'plotOnBitmapUsingColorWithRefreshAtRefreshRate' is passed to the client *)
and plotOnBitmapUsingColorWithRefreshAtRefreshRate (c:Color)  =
  let plotter (i,j) = (!(force bitmap') : Bitmap).SetPixel(i,j,c) in 
  let refresher (minX,minY,maxX,maxY) =
    Application.DoEvents();
    if (not !exitSemaphore) then begin
      let graphics = (cast (force form') : Control).CreateGraphics() in 
      graphics.DrawImage((cast !(force bitmap') : Image),
			 new Rectangle((minX-1)*magnification,
				       (minY-1)*magnification,
				       ((maxX- minX)+3)*magnification,
				       ((maxY- minY)+3)*magnification),              
			 new Rectangle(minX-1,minY-1,(maxX- minX)+3,(maxY- minY)+3),
			 GraphicsUnit.Pixel);
      graphics.Dispose()
    end;
    if (!interruptSemaphore)  then raise Interrupt in 
  let plotter',refresher' = refreshPlottedAreaOnly (plotter,refresher) in 
  plotWithRefreshAtRefreshRate (plotter',refresher')

(* These actions are referred by the menu items above. *)
and go () = 
  (force goMenuItem').Enabled <- false;
  (force interruptMenuItem').Enabled <- true;
  (force bitmap') := new_empty_bitmap(); 
  (force form').Invalidate(); 
  (force form').Update(); 
  (try Server.life(plotOnBitmapUsingColorWithRefreshAtRefreshRate liveColor,
		   plotOnBitmapUsingColorWithRefreshAtRefreshRate backgroundColor,
		   displaySize) with Interrupt -> ());
  (force interruptMenuItem').Enabled <- false;
  interruptSemaphore := false;
  (force goMenuItem').Enabled <- true

and interrupt () = 
  if not (force goMenuItem').Enabled then begin
    (force goMenuItem').Enabled <- true;        
    (force interruptMenuItem').Enabled <- false;
    interruptSemaphore := true
  end

(* The last item in the system of recursive specifications *)
(* is an action which actually runs the application using the given *)
(* form. *)
and act11' = lazy (Application.Run(force form'))


(* The final part of the file is to resolve all the objects and *)
(* actions in the recursive system specified above. *)
let bitmap = force bitmap'
let form = force form'
let act0 = force act0'
let act1 = force act1'
let act2 = force act2'
let act3 = force act3'
let act4 = force act4'
let act5 = force act5'
let fileMenu = force fileMenu'
let interruptMenuItem = force interruptMenuItem' 
let goMenuItem = force goMenuItem' 
let act6 = force act6'
let act7 = force act7'
let act8 = force act8'
let act9 = force act9'
let act10 = force act10'
let act11 = force act11'


