// Clients which wish to display the results of a Game-Of-Life
// computation should implement this class.

public abstract class LifeClient 
{
   public abstract void Set (int x, int y);
   public abstract void Clear (int x, int y);
   public abstract int Size { get;  }
}









