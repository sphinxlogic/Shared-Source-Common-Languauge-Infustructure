open System
open System.Reflection
open System.IO

type search = 
  | ExactMatch 
  | NamespaceMatch 

let kind = ref ExactMatch
let interfaces = ref false
let methods = ref false
let basetypes = ref false
let modinfo = ref false
let verbose = ref false
let includes = ref []
let deep = ref false
  
let findDLLs (dir:string) =
  if (Directory.Exists dir) then
    let files = Directory.GetFiles(dir, "*.dll") in 
    Arr.to_list files
  else
    (if !verbose then prerr_endline("Directory "^dir^" does not exist!"); [])

let print_indented ind s = 
  for i = 1 to ind do print_char ' '; done;
  print_endline s

let rec dumpType ind shallow (t:Type) =
  let baseType = t.BaseType in 
  let desc = 
    if t.IsClass then "class"
    else if t.IsInterface then "interface" 
    else if t.IsValueType then "struct" 
    else if t.IsArray then "array" 
    else "??" in 
  print_indented ind (desc^" "^t.FullName);
  if not shallow then begin
    if !kind = ExactMatch or !modinfo then 
      print_indented (ind+2) ("Module: "^ t.Module.FullyQualifiedName );
    if !kind = ExactMatch or !interfaces then begin
      let intfs = t.GetInterfaces() in 
      for i = 0 to Arr.length intfs - 1 do
	dumpType (ind+2) true (Arr.get intfs i);
      done;
    end;
  end;
  if (!basetypes & nonnull baseType) then 
    dumpType 0 shallow baseType
     
let searchFile (pat:string) file = 
  (* Load the module - expect to fail if it is not a .NET module *)
  match (try Some (Assembly.LoadFrom(file)) with _ -> None) with
  | Some a ->
      let modules = a.GetModules() in
      let pat = pat.ToUpper() in 
      if !verbose then prerr_endline("Searching Module "^file);
      if (nonnull modules) then
	for i = 0 to (* modules.Size *) Arr.length modules - 1 do 
	  let m = (* modules.[i] *) Arr.get modules i in 
	  let types = 
	    try m.GetTypes() 
	    with _ -> prerr_endline ("Types in module "^m.Name^" failed to load\n"); Arr.zero_create 0 in 
	  for j = 0 to (* types.Size *) Arr.length types - 1 do
	    let t = (* types.[j] *) Arr.get types j in 
            let name = t.FullName.ToUpper() in 
            let show = 
	      match !kind with 
	      | ExactMatch -> name = pat
	      | NamespaceMatch -> 
		  nonnull t.Namespace & t.Namespace.ToUpper() = pat
	    in 
	    if show then dumpType 0 false t
	  done;
	done
  | None -> ()

let searchDir pat dir = 
  List.iter (searchFile pat) (findDLLs dir)

let search pat =
  let mscorlib = Assembly.Load("mscorlib.dll") in 
  if !verbose then prerr_endline "Searching System Libraries";  
  let dirFrameworks = Path.GetDirectoryName(mscorlib.Location) in 
  searchDir pat dirFrameworks;
  if !verbose then prerr_endline "Searching the current directory...";  
  searchDir pat ".";
  List.iter (fun dir -> 
    if !verbose then prerr_endline ("Searching directory "^dir);      
    searchDir pat dir) !includes

let usage =
  [ "-x", Arg.Unit (fun _ -> kind := ExactMatch), "Exact Type Name (including namespace)";
    "-n",  Arg.Unit (fun _ ->  kind := NamespaceMatch), "Search for namespace";
    "-I",  Arg.String (fun s -> includes := !includes @ [s]), "Extra search directory";
    "-w",  Arg.Set deep, "Match the name anywhere in the namespace";
    "-i",  Arg.Set interfaces, "Show interfaces";
    "-r",  Arg.Set basetypes, "Show base types";
    "-a",  Arg.Unit (fun () -> interfaces := true), "Show all";
    "-l",  Arg.Set modinfo, "Show module information";
    "-v",  Arg.Set verbose, "Verbose"; ]

let _ = 
    Arg.parse usage search "findtype <options> name1 name2 ... "
